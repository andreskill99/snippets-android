start compiler.exe cp.txt


